import package

# homework 1
users = package.manage_users.get_users()
new_users = package.manage_users.add_new_keys(users, color="black")
print("homework 1", new_users)
package.manage_users.save_users(new_users)

# homework 2
numbers = [[[[[10]]]]]
number = package.get_number.get_number(numbers)
print("homework 2", number)

# homework 3
numbers = [1, 2, [3, 4], [5, 6, [10, 29, 10]]]
sum_numbers = package.get_recursive_sum.sum_of_nested_list(numbers)
print("homework 3", sum_numbers)
