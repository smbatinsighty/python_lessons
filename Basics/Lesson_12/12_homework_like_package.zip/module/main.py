import script

numbers = script.numbers

print(script.get_number(numbers))
print("name from main.py", __name__)
