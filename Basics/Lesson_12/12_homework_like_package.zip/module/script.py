numbers = [[[[[10]]]]]

print("script imported")


# get number from list
def get_number(numbers):
    if not isinstance(numbers, list):
        return numbers
    else:
        return get_number(numbers[0])


print("name from script.py", __name__)
