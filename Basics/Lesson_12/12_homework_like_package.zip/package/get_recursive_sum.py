def sum_of_nested_list(nested_list):
    if not isinstance(nested_list, list):
        return nested_list
    if not nested_list:
        return 0
    return sum_of_nested_list(nested_list[0]) + sum_of_nested_list(nested_list[1:])
