# homework 11 1.1
def get_users():
    with open("db.txt") as file:
        users = []
        for i, line in enumerate(file.readlines()):
            if i == 0:
                keys = list(line.strip().split(","))
            else:
                users.append(dict(zip(keys, list(line.strip().split(",")))))

    new_user = {}
    for key in keys:
        new_user[key] = input("enter your {}: ".format(key))
    users.append(new_user)
    return users


# homework 11 1.2
def add_new_keys(users, **kwargs):
    for user in users:
        user.update(kwargs)
    return users


# homework 11 1.3
def save_users(users):
    with open("db.txt", "w") as file:
        keys = ",".join(users[0].keys())
        file.write((str(keys)) + "\n")

        for user in users:
            file.write(",".join(user.values()) + "\n")
