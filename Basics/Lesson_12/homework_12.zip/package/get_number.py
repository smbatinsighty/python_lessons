# lesson 11 homework 2
numbers = [[[[[10]]]]]


# get number from list
def get_number(numbers):
    if not isinstance(numbers, list):
        return numbers

    return get_number(numbers[0])


print("name from script.py", __name__)
