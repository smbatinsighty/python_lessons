numbers = [1, 2, [3, 4], [5, 6, [10, 29, 10]]]


def sum_of_nested_list(nested_list):
    if not isinstance(nested_list, list):
        return nested_list
    if not nested_list:
        return 0
    return sum_of_nested_list(nested_list[0]) + sum_of_nested_list(nested_list[1:])


x = sum_of_nested_list(numbers)
print(x)
