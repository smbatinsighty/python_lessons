import package
# from package import get_number
# from package import get_recursive_sum
# from package import manage_users

print(package.get_number.get_number([[[[7]]]]))
# print(package.get_recursive_sum.sum_of_nested_list([[[[7]]]]))

# print(dir(package))
# print(package.__file__)
